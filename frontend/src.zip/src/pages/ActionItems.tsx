import { useEffect, useState } from "react";

import Header from "../components/Header";
import ActionItemCard from "../components/ActionItemCard";

import { getActionItems } from "../services/actionItemApi";

import type { HCPActionGroup } from "../types/actionItem";

import "./ActionItems.css";

export default function ActionItems() {
  const [groups, setGroups] = useState<HCPActionGroup[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    loadActionItems();
  }, []);

  async function loadActionItems() {
    try {
      setLoading(true);

      const response = await getActionItems();

      setGroups(response.data);
    } catch (err) {
      console.error(err);
      setError("Failed to load action items.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <>
      <Header />

      <main className="action-items-page">
        <div className="action-items-header">
          <h2>Action Items</h2>

          <p>
            Track pending follow-ups generated from Healthcare Professional
            interactions.
          </p>
        </div>

        {loading && (
          <div className="empty-state">
            <p>Loading action items...</p>
          </div>
        )}

        {!loading && error && (
          <div className="empty-state">
            <p>{error}</p>
          </div>
        )}

        {!loading && !error && groups.length === 0 && (
          <div className="empty-state">
            <h3>🎉 You're all caught up!</h3>

            <p>
              No pending action items were found. New follow-up tasks will
              automatically appear here after you save interactions.
            </p>
          </div>
        )}

        {!loading &&
          !error &&
          groups.map((group) => (
            <ActionItemCard
              key={group.hcp.id}
              group={group}
            />
          ))}
      </main>
    </>
  );
}