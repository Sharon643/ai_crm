import axios from "axios";

const API = "http://localhost:8000";

export const getActionItems = () =>
    axios.get(`${API}/action-items`);

export const updateActionItem = (
    id: number,
    status: "Pending" | "Completed"
) =>
    axios.patch(`${API}/action-items/${id}`, {
        status,
    });