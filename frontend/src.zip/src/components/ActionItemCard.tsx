import { useMemo } from "react";

import { updateActionItem } from "../services/actionItemApi";

import type {
  HCPActionGroup,
  Task,
} from "../types/actionItem";

import "./ActionItemCard.css";

interface Props {
  group: HCPActionGroup;
}

export default function ActionItemCard({
  group,
}: Props) {
  const pending = useMemo(
    () =>
      group.tasks.filter(
        (task) => task.status === "Pending"
      ),
    [group.tasks]
  );

  const completed = useMemo(
    () =>
      group.tasks.filter(
        (task) =>
          task.status === "Completed"
      ),
    [group.tasks]
  );

  async function toggleTask(
    task: Task
  ) {
    const status =
      task.status === "Pending"
        ? "Completed"
        : "Pending";

    try {
      await updateActionItem(
        task.id,
        status
      );

      window.location.reload();
    } catch (err) {
      console.error(err);
    }
  }

  function badge(priority: string) {
    switch (priority) {
      case "High":
        return "priority high";

      case "Medium":
        return "priority medium";

      default:
        return "priority low";
    }
  }

  return (
    <div className="hcp-card">

      <div className="hcp-header">

        <div>

          <h3>{group.hcp.name}</h3>

          <p>{group.hcp.hospital}</p>

        </div>

        <div className="counts">

          <span className="pending">
            {group.pending} Pending
          </span>

          <span className="completed">
            {group.completed} Completed
          </span>

        </div>

      </div>

      {pending.length > 0 && (
        <>

          <h4>Pending</h4>

          {pending.map((task) => (
            <TaskRow
              key={task.id}
              task={task}
              badge={badge}
              toggleTask={toggleTask}
            />
          ))}

        </>
      )}

      {completed.length > 0 && (
        <>

          <h4 className="completed-title">
            Completed
          </h4>

          {completed.map((task) => (
            <TaskRow
              key={task.id}
              task={task}
              badge={badge}
              toggleTask={toggleTask}
            />
          ))}

        </>
      )}

    </div>
  );
}

interface RowProps {
  task: Task;

  badge: (
    priority: string
  ) => string;

  toggleTask: (
    task: Task
  ) => void;
}

function TaskRow({
  task,
  badge,
  toggleTask,
}: RowProps) {
  return (
    <div className="task">

      <label>

        <input
          type="checkbox"
          checked={
            task.status === "Completed"
          }
          onChange={() =>
            toggleTask(task)
          }
        />

        <span>{task.title}</span>

      </label>

      <span
        className={badge(
          task.priority
        )}
      >
        {task.priority}
      </span>

    </div>
  );
}